// add and export the requested function here (see instructions)
export function getRandomInt(min, max){
    return Math.round(Math.random() * (max - min) + min);
}