export const randomWord = (array) => {
    return array[Math.floor(Math.random() * array.length)];
}